import pygame
import os
import random
import sqlite3

# Initialize Pygame
pygame.init()

# Screen Setup
WIDTH, HEIGHT = 500, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Groepswerk 1")

# Colors
COLOR = (255, 255, 255)
RED = (255, 0, 0)

# Game Constants
FPS = 60
VELOCITY = 7
BULLET_VEL = 7
MAX_BULLETS = 3
LIVES = 3
POINTS = 50

# Events
METEOR_HIT = pygame.USEREVENT + 1

# Load Background Image
SPACE_IMAGE = pygame.image.load(os.path.join("Assets", "space_bg.jpg"))
SPACE = pygame.transform.scale(SPACE_IMAGE, (WIDTH, HEIGHT))


# SQLite Database Setup
def init_db():
    conn = sqlite3.connect("game_scores.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            score INTEGER
        )
    """)
    conn.commit()
    conn.close()


def save_score(player_name, score):
    conn = sqlite3.connect("game_scores.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO scores (name, score) VALUES (?, ?)", (player_name, score))
    conn.commit()
    conn.close()


def get_high_scores(limit=10):
    conn = sqlite3.connect("game_scores.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, score FROM scores ORDER BY score DESC LIMIT ?", (limit,))
    high_scores = cursor.fetchall()
    conn.close()
    return high_scores


# Show High Scores
def show_scores():
    scores = get_high_scores()
    run = True
    while run:
        WIN.blit(SPACE, (0, 0))  # Use the background from your asset
        font = pygame.font.SysFont(None, 30)
        title = font.render("High Scores", True, (0, 255, 255))
        WIN.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))

        y_offset = 100
        for i, (name, score) in enumerate(scores):
            score_text = font.render(f"{i + 1}. {name}: {score}", True, COLOR)
            WIN.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, y_offset))
            y_offset += 40

        back_text = font.render("Press ESC to quit", True, COLOR)
        WIN.blit(back_text, (WIDTH // 2 - back_text.get_width() // 2, HEIGHT - 50))
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: # on ESC key pressed: quit
                    run = False
                    pygame.quit()


# Classes
class Spaceship:
    '''Spaceship class to create the player spaceship.'''
    def __init__(self, image_name):
        self.image_name = image_name # make the given asset name match
        self.SPACESHIP_WIDTH, self.SPACESHIP_HEIGHT = 80, 100 # Define sizes
        SPACESHIP_IMAGE = pygame.image.load(os.path.join("Assets", image_name)) # load in image
        self.SPACESHIP = pygame.transform.scale(SPACESHIP_IMAGE, (self.SPACESHIP_WIDTH, self.SPACESHIP_HEIGHT)) # Apply sizes
        self.ship = pygame.Rect((250 - (self.SPACESHIP_WIDTH / 2)), 650, self.SPACESHIP_WIDTH, self.SPACESHIP_HEIGHT) # create a rect to base game logic off of
        self.lives = LIVES
        self.score = 0


class Meteor:
    '''Meteor class to create the meteors from.'''
    def __init__(self, image_name):
        self.image_name = image_name # make the given asset name match
        self.METEOR_WIDTH, self.METEOR_HEIGHT = random.randint(50, 100), random.randint(50, 100) # Define randomized sizes
        self.METEOR_IMAGE = pygame.image.load(os.path.join("Assets", image_name)) # load in image
        self.METEOR = pygame.transform.scale(self.METEOR_IMAGE, (self.METEOR_WIDTH, self.METEOR_HEIGHT)) # create a rect to base game logic off of
        self.transform = pygame.Rect(random.randint(self.METEOR_WIDTH, WIDTH - self.METEOR_WIDTH),
                                     random.randint(-100, -50), self.METEOR_WIDTH,
                                     self.METEOR_HEIGHT)

        self.speeds = random.randint(1, 3)
        self.x_speeds = random.choice([-1, 1]) * random.uniform(0.5, 0.8)

    def move(self):
        self.transform.y += self.speeds
        self.transform.x += self.x_speeds

        if self.transform.left <= 0:
            self.x_speeds = abs(self.x_speeds)

        elif self.transform.right >= WIDTH:
            self.x_speeds = -abs(self.x_speeds)

        if self.transform.y > HEIGHT:
            self.transform.y = random.randint(-100, -50)
            self.transform.x = random.randint(self.METEOR_WIDTH, WIDTH - self.METEOR_WIDTH)


METEOR_TYPES = ["meteor_01.png", "meteor_02.png", "meteor_03.png", "meteor_04.png"]

METEOR_01 = Meteor(METEOR_TYPES[0])
METEORS = [METEOR_01]
PLAYER = Spaceship("ship.png")


def draw_window(PLAYER, bullets, elapsed_time, name_input=False, name=""):
    WIN.blit(SPACE, (0, 0))  # Use the background image
    WIN.blit(PLAYER.SPACESHIP, (PLAYER.ship.x, PLAYER.ship.y))

    for meteor in METEORS:
        WIN.blit(meteor.METEOR, (meteor.transform.x, meteor.transform.y))

    for bullet in bullets:
        pygame.draw.rect(WIN, RED, bullet)

    # Lives
    font = pygame.font.SysFont(None, 30)
    lives_text = font.render(f"Lives: {PLAYER.lives}", True, (0, 255, 255))
    WIN.blit(lives_text, (WIDTH - 100, 10))

    # Score
    score_text = font.render(f"Score: {PLAYER.score}", True, (0, 255, 255))
    WIN.blit(score_text, (10, 10))

    # Time
    minutes = (elapsed_time // 1000) // 60
    seconds = (elapsed_time // 1000) % 60
    time_text = font.render(f"Time: {minutes:02}:{seconds:02}", True, (0, 255, 255))
    WIN.blit(time_text, (WIDTH - 145, HEIGHT - 35))

    # If name input stage
    if name_input:
        # Create a semi-transparent black overlay
        overlay = pygame.Surface((WIDTH, HEIGHT))  # Create an overlay with the same size as the window
        overlay.fill((0, 0, 0))  # Fill with black
        overlay.set_alpha(128)  # Set transparency (0 is fully transparent, 255 is fully opaque)
        WIN.blit(overlay, (0, 0))  # Draw the overlay on top of everything else

        # Input prompt text
        input_text = font.render(f"Enter your name: {name}", True, (0, 255, 255))
        WIN.blit(input_text, (WIDTH // 2 - 100, HEIGHT // 2))

    pygame.display.update()


def movement(keys_pressed, PLAYER):
    if keys_pressed[pygame.K_LEFT]: # Left arrow: move left
        PLAYER.ship.x -= 10
    if keys_pressed[pygame.K_RIGHT]: # Right arrow: move right
        PLAYER.ship.x += 10

    # Make sure ship stays within screen bounds
    if PLAYER.ship.x <= 0:
        PLAYER.ship.x = 0
    if PLAYER.ship.x >= (WIDTH - PLAYER.SPACESHIP_WIDTH):
        PLAYER.ship.x = (WIDTH - PLAYER.SPACESHIP_WIDTH)


def handle_bullets(bullets, METEORS):
    # Avoid trying to delete deleted items
    to_remove_bullets = []
    to_remove_meteors = []

    for bullet in bullets:
        bullet.y -= BULLET_VEL # Bullets shoot upwards

        # Post event on collision
        for meteor in METEORS:
            if meteor.transform.colliderect(bullet):
                pygame.event.post(pygame.event.Event(METEOR_HIT, meteor=meteor))
                to_remove_bullets.append(bullet)
                to_remove_meteors.append(meteor)
                break  # No need to check further if the bullet hits a meteor

        if bullet.y < 0:
            to_remove_bullets.append(bullet)

    # Remove all bullets and meteors in one go after the loop
    for bullet in to_remove_bullets:
        if bullet in bullets:  # Check if the bullet is still in the list
            bullets.remove(bullet)
    for meteor in to_remove_meteors:
        if meteor in METEORS:  # Check if the meteor is still in the list
            METEORS.remove(meteor)


def meteor_interact(PLAYER, METEORS):
# Lose a life when hit
    for meteor in METEORS[:]:
        if PLAYER.ship.colliderect(meteor.transform):
            PLAYER.lives -= 1
            METEORS.remove(meteor)
            METEORS.append(respawn_meteor())
            return True
    return False


def respawn_meteor():
    return Meteor(random.choice(METEOR_TYPES))


def get_player_name():
    name = ""
    font = pygame.font.SysFont(None, 25)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return None

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Player hits Enter to finish input
                    return name
                elif event.key == pygame.K_BACKSPACE:  # Backspace functionality
                    name = name[:-1]
                else:
                    name += event.unicode

        draw_window(PLAYER, [], 0, name_input=True, name=name)


def main():
    bullets = []

    clock = pygame.time.Clock()
    start_time = pygame.time.get_ticks()
    meteor_time = pygame.time.get_ticks()
    run = True

    while run:
        clock.tick(FPS)

        elapsed_time = pygame.time.get_ticks() - start_time

        current_time = pygame.time.get_ticks()

        if current_time - meteor_time >= 10000:
            METEORS.append(Meteor(random.choice(METEOR_TYPES)))
            meteor_time = current_time

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.KEYDOWN:
                # When spacebar is pressed and less than 3 bullets are shown on screen, make a new bullet
                if event.key == pygame.K_SPACE and len(bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(PLAYER.ship.x + (PLAYER.ship.width // 2 - 3), PLAYER.ship.y, 6, 20)
                    bullets.append(bullet)

            if event.type == METEOR_HIT:
                PLAYER.score += POINTS
                METEORS.append(respawn_meteor())

        # Game over check
        if PLAYER.lives <= 0:
            name = get_player_name()  # Call name input when player dies
            if name:
                save_score(name, PLAYER.score)  # Save the score to the database
            run = False
            continue  # End the loop and move to the game over stage

        keys_pressed = pygame.key.get_pressed()
        movement(keys_pressed, PLAYER)

        handle_bullets(bullets, METEORS)

        for meteor in METEORS: # Meteors go vroom
            meteor.move()

        if meteor_interact(PLAYER, METEORS): # When ship is hit, put it back in the middle of the screen
            PLAYER.ship.x = 250 - (PLAYER.SPACESHIP_WIDTH / 2)
            PLAYER.ship.y = 650

        draw_window(PLAYER, bullets, elapsed_time)

    # Show high scores after the game ends
    show_scores()
    pygame.quit()


if __name__ == '__main__':
    init_db()  # Initialize the database
    main()